# 抓取更新公告并进行推送
## 全平台通用，请注意安装依赖
### nodejs  python（filecmp、requests、shutil、lxml）
### 6.py为 结果不同（视为更新）然后进行api post
# 使用方法
## 克隆本仓库或者分支  克隆方法git clone git@github.com:Marcus-Lacia/NEWS.git
### 若使用分支，则
>  git add -A 
>  git commit -m "announce updates"
>  git push -u origin main
### 不需要删除，同时可以享受github推送更新邮件通知
### 若克隆，请删除上述代码避免无用的提交

## Crawl update announcements and push them
## Universal for all platforms, please note the installation of dependencies
### nodejs python (filecmp, requests, shutil, lxml)
### 6.py for Results are different (considered as updates) then api post
### Usage
## Clone this repository or branch Clone method git clone git@github.com:Marcus-Lacia/NEWS.git
### If you use a branch, then
>  git add -A 
>  git commit -m "announce updates"
>  git push -u origin main
### You don't need to delete it, and you can enjoy github push email notifications for updates
### If cloning, remove the above code to avoid useless commits


Translated with www.DeepL.com/Translator (free version)
